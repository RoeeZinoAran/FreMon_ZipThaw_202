
void send_debug_values(void);
