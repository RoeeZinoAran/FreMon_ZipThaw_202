
#define OK                   0
#define FAIL1                1
#define FAIL2                2
#define FAIL3                3
#define FAIL4                4
#define FAIL5                5
#define FAIL6                6
