
void init(void);
void init_heating_pwm(void);
void init_rgb_leds(void);
void init_receiving_from_som(void);
