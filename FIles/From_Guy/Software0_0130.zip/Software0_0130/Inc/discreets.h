

unsigned short get_som_comm_address(void);

void get_motor_index(void);
void get_door_state(void);

void rgb_leds(unsigned short red, unsigned short green, unsigned short blue);


#define DOOR_OPEN     0
#define DOOR_CLOSED   1

