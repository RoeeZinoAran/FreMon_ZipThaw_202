
#include "error.h"

void errors_top(void)
{
}
